from django.http import HttpResponse
from django.shortcuts import render

from .models import Menu
from django.core import serializers
from .models import Booking
from datetime import datetime
import json
from .forms import BookingForm

def home(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

# make bookings 
def book(request):
    form = BookingForm()
    message = 'Make your reservation here!'
    if request.method == 'POST':
        form = BookingForm(request.POST)
        booking_slot_is_taken = Booking.objects.filter(reservation_date=form.data['reservation_date'], reservation_slot=form.data['reservation_slot']).all()
        if booking_slot_is_taken:
            print("Booking slot is already taken. Reservation denied!")
            message = 'This time and date is already taken. Please try another timeslot or date. \nThank you!'
        else: 
            if form.is_valid():
                form.save()
                message = 'Your reservation was successfull. See you then!'
    context = {'form':form, 'message': message}
    return render(request, 'book.html', context)

# view all bookings 
def bookings(req):
    if req.method == 'GET':
        if req.GET.get('date'): 
            date = req.GET.get('date')
            print(date)
        else: date = req.GET.get('date',datetime.today().date())
        bookings = Booking.objects.filter(reservation_date=date).all()
        booking_json = serializers.serialize('json', bookings)
        print(booking_json)
        return render(req, 'bookings.html', {'bookings': booking_json})
    

def menu(request):
    menu_data = Menu.objects.all()
    main_data = {"menu": menu_data}
    return render(request, 'menu.html', {"menu": main_data})


def display_menu_item(request, pk=None): 
    if pk: 
        menu_item = Menu.objects.get(pk=pk) 
    else: 
        menu_item = "" 
    return render(request, 'menu_item.html', {"menu_item": menu_item}) 